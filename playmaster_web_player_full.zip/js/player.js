
document.getElementById('loadBtn').addEventListener('click', function() {
  const video = document.getElementById('iptvPlayer');
  const m3uUrl = "http://play.biturl.vip/get.php?username=Playmaster&password=e6fx7fmxp3l&type=m3u_plus&output=ts";
  video.src = m3uUrl;
  video.play();
});
